function bang() 
{
    outlet(0, this.patcher.name);
}