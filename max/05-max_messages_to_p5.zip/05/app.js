const express = require('express')
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const path = require('path');

server.listen(3000);
// WARNING: app.listen(80) will NOT work here!

app.use(express.static(path.join(__dirname, 'canon')));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

const p5js = io
    .of('/p5js')
    .on('connection', (socket) => {
        console.log("P5js sketch connected");
    });

io.on('connection', (socket) => {
    console.log("We have a new client: " + socket.id);
    socket.on('voice', function(data) {
        // Data comes in as whatever was sent, including objects
        console.log("Received: " + data.zerox + " from " + socket.id);
        p5js.emit('voice', socket.id, data);
        });
    socket.on('disconnect', function() {
      console.log("Client has disconnected");
    });
});


