const maxApi = require('max-api');
const io = require('socket.io-client');

let socket;

maxApi.addHandler('connect', (url) => {
	socket = io.connect(url);
	maxApi.addHandler('voice', (arg1, arg2, arg3) => {
	var sendData = {
	    zerox: arg1,
	    f: arg2,
		amp: arg3
	};
	socket.emit('voice', sendData);
})
})

maxApi.addHandler('disconnect', () => {
	socket.close();
})

