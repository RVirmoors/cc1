let font, fontsize = 40;
let colors = [];
let clients = []; // populate as clients connect
let socket;

function preload() {
  // Ensure the .ttf or .otf font stored in the assets directory
  // is loaded before setup() and draw() are called
  font = loadFont('data/SourceSansPro-Regular.otf');
}

function setup() {
  socket = io.connect('http://localhost:3000/p5js');
  socket.on('voice',
    function(sid, data) {
      console.log(sid, data);
    }
  );
  
  createCanvas(500, 500);  
  background(255);
  // Set text characteristics
  textFont(font);
  textSize(fontsize);
  
  colors = [color('#000000'),color('#FF0000'),color('#00FF00'),color('#0000FF')];
}


function draw() {
  if (clients.length) {
    let lci = clients.length - 1; // last client index
    clients[lci].update();
    clients[lci].drawStatus();
    clients[lci].drawTrace();
  }
}

function mousePressed() {
  if (clients.length < 4) {
    clients.push(new Client());
    let lci = clients.length - 1; // last client index
    clients[lci].color = colors[lci];
    console.log(clients.length);
  }
}
