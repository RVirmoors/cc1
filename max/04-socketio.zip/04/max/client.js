const maxApi = require('max-api');
const io = require('socket.io-client');

let socket;

maxApi.addHandler('connect', (url) => {
	socket = io.connect(url);
})

maxApi.addHandler('disconnect', () => {
	socket.close();
})