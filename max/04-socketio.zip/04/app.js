const express = require('express')
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const path = require('path');

server.listen(3000);
// WARNING: app.listen(80) will NOT work here!

app.use(express.static(path.join(__dirname, 'canon')));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
    console.log("We have a new client: " + socket.id);
    socket.on('disconnect', function() {
      console.log("Client has disconnected");
    });
});
