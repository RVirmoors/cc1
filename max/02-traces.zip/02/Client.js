class Client {
  constructor() {
    this.zerox = 0;
    this.f = 0;
    this.amp = 0;
    this.color = color(0,0,0);
    // position:
    this.x = 0;
    this.y = 1;
    this.lastX = 0;
    this.base = 1;
  }
  
  update() {
    this.zerox = mouseY;
    this.f = mouseX / 10;
    this.amp = abs(mouseX - pmouseX) / 5;
    
    if (this.amp) {
      // singing: let's move
      if (this.zerox < 40) {
        // stable: go vertical!
        this.y = this.base + this.f;
        this.lastX = this.x;
      } else {
        // noisy: go horizontal, establish base!
        this.base = this.y;
        this.lastX = this.x;
        this.x += this.amp;
      }
    } else {
      // not singing: drop back down
      this.y = 1;
    }
    this.x = this.x % width;
  }
  
  drawStatus() {
    fill(255);
    strokeWeight(0);
    rect(20, 20, 400, 40);
    fill(this.color);
    strokeWeight(1);
    text(this.zerox + " " +
        this.f + " " +
        this.amp, 
        20, 60); // place text here
  }
  
  drawTrace() {
    stroke(this.color);    
    strokeWeight(3);
    line(this.lastX, height-this.base, this.x, height-this.y);
  }
}
