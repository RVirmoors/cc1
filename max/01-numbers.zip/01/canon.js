let font, fontsize = 40;
let colors = [];
let clients = []; // populate as clients connect

function preload() {
  // Ensure the .ttf or .otf font stored in the assets directory
  // is loaded before setup() and draw() are called
  font = loadFont('data/SourceSansPro-Regular.otf');
}

function setup() {
  createCanvas(500, 500);
  // Set text characteristics
  textFont(font);
  textSize(fontsize);
  
  colors = [color('#000000'),color('#FF0000'),color('#00FF00'),color('#0000FF')];
}


function draw() {
  background(255);
  if (clients.length) {
    let lci = clients.length - 1; // last client index
    clients[lci].zerox = mouseY;
    clients[lci].f = mouseX / 10;
    clients[lci].amp = abs(mouseX - pmouseX) / 5;
    fill(clients[lci].color);
    text(clients[lci].zerox + " " +
        clients[lci].f + " " +
        clients[lci].amp, 20,60);
  }

}

function mousePressed() {
  if (clients.length < 4) {
    clients.push(new Client());
    let lci = clients.length - 1; // last client index
    clients[lci].color = colors[lci];
    console.log(clients.length);
  }
}
