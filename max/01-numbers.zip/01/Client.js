class Client {
  constructor() {
    this.zerox = 0;
    this.f = 0;
    this.amp = 0;
    this.color = color(0,0,0);
  }
}
