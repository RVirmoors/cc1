let connectURL = 'https://secret-waters-16893.herokuapp.com/p5js';//'http://localhost:3000/p5js';

let font, fontsize = 40;
let colors = [];
let clients = []; // populate as clients connect
let sids = [];    // socket IDs for each client
let socket;
let y = 1, base = 1, x = 0, lastX = 0;    // position

function preload() {
  // Ensure the .ttf or .otf font stored in the assets directory
  // is loaded before setup() and draw() are called
  font = loadFont('data/SourceSansPro-Regular.otf');
}

function setup() {
  socket = io.connect(connectURL);
  socket.on('newClient', (sid) => newClient(sid));
  socket.on('voice', (sid, data) => {
//    console.log(sid, data);
    clients[getId(sid)].update(data);
  });
  
  createCanvas(500, 500);  
  background(255);
  // Set text characteristics
  textFont(font);
  textSize(fontsize);
  
  colors = [color('#000000'),color('#FF0000'),color('#00FF00'),color('#0000FF')];
}


function draw() {
  if (clients.length) {
    let lci = getLci(); // largest client index
    clients[lci].drawStatus();
    updatePosition(lci);
    drawTrace(lci);
  }
}

function newClient(sid) {
  if (clients.length < 4) {
    clients.push(new Client());
    sids.push(sid);
    let lci = clients.length - 1; // last client index
    clients[lci].color = colors[lci];
    console.log("Connected clients: " + clients.length);
  }
}

function getId(sid) {
  // get client index from sid
  for (var i = 0; i < clients.length; i++) {
    if(sids[i] == sid) {
      return i;
    }
  }
}

function getLci() {
  // get index of client with max amp
  var max = 0, maxId = 0;
  for (var i = 0; i < clients.length; i++) {
    if(clients[i].amp > max) {
      max = clients[i].amp;
      maxId = i;
    }
  }
//  console.log("maxID: " + maxId);
  return maxId;
}

function updatePosition(clientIndex) {
  if (clients[clientIndex].amp) {
      // singing: let's move
      if (clients[clientIndex].zerox < 2) {
        // stable: go vertical!
        y = base + clients[clientIndex].f;
        lastX = x;
      } else {
        // noisy: establish base, go horizontal!
        base = y;
        lastX = x;
        x += clients[clientIndex].amp;
      }
    } else {
      // nobody is singing: drop back down
      y = base = 1;
    }
    x = x % width;
}

function drawTrace(clientIndex) {
  stroke(colors[clientIndex]);    
  strokeWeight(3);
  line(lastX, height-base, x, height-y);
}
