class Client {
  constructor() {
    this.zerox = 0;
    this.f = 0;
    this.amp = 0;
    this.color = color(0,0,0);
  }
  
  update(data) {
    this.zerox = data.zerox;
    this.f = data.f / 20;
    this.amp = data.amp;
  }
  
  drawStatus() {
    fill(255);
    strokeWeight(0);
    rect(20, 20, 400, 40);
    fill(this.color);
    strokeWeight(1);
    text(this.zerox + " " +
        this.f.toFixed(2) + " " +
        this.amp.toFixed(2), 
        20, 60); // place text here
  }
}
